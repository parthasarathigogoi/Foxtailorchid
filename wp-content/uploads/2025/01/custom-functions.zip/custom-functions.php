<?php
/*
Plugin Name: Custom Functions
Description: A plugin to add custom functions.
Version: 1.0
Author: Your Name
*/

function custom_fix_checkout_button() {
    echo '<style>
        .woocommerce-checkout .button.checkout-button {
            display: block !important;
        }
    </style>';
}
add_action('wp_head', 'custom_fix_checkout_button');
